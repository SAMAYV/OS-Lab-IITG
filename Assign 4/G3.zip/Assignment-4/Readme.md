# Assignment 4: Group 3
Please follow the following instructions for installation of respective file systems and create workload using vdbench.
**Assumptions:**
- vdbench is installed in the system in the folder *vdbench*.
- Extract the G3.rar submission folder.

## Journaling

**Creation of ext2/ext4 file system using terminal**:
- sudo parted /dev/sdb
- mklabel msdos
- mkpart
	> Partition type? primary/extended? primary
	> File system type? ext2/ext4          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    [Enter the appropriate file-system]
	> Start? 1
	> End? 20190
- sudo mkfs.ext2 /dev/sdb1
- sudo e2label /dev/sdb1 disk2-part1
- mkdir /mnt/disk2-part1
- mount /dev/sdb1 //mnt/disk2-part1
***See report for detailed screenshots***

 ### Workload for ext4:
- Copy the file **Assignment-4/Journalling/create_files_ext4** to the folder **vdbench**
- Create the **ext4** disk partition.
- The anchor value in the **fsd** field inside the **create_files_ext4** file is the location of the partition equipped ext4 filesystem. We used */media/$USER/disk_name/folder_name*, where **disk_name** is the name of ext4 disk partition and **folder_name** is the folder inside which workload files are generated.
- *sudo ./vdbench -j -f ./create_files_ext4 -o ext4_output*
- Here **create_files_ext4** is the executed file, **ext4_output** is the folder in which the output files will be generated.
 ### Workload for ext2:
- Copy the file **Assignment-4/Journalling/create_files_ext2** to the folder **vdbench**
- Create the **ext2** disk partition.
- The anchor value in the **fsd** field inside the **create_files_ext2** file is the location of the used partition for **ext2** filesystem. We used */media/$USER/disk_name/folder_name*, where **disk_name** is the name of ext2 disk partition and **folder_name** is the folder inside which workload files are generated.
- *sudo ./vdbench -j -f ./create_files_ext2 -o ext2_output* 
- Here **create_files_ext2** is the executed file, **ext2_output** is the folder in which the output files will be generated.

## Deduplication
**Creation of ZFS file system**:
- sudo apt install zfsutils-linux
- sudo zpool create -f zfs1 /dev/sdb1
- Here zfs1 is the pool name and /dev/sdb1 is the location of the disk partition used for the zfs filesystem where all the workload is generated.
- Create the zfs disk partition and create a pool named zfs1
***See report for detailed screenshots***

### Workload for dedup=on:
- Copy the file **Assignment-4/dedup/test1** to the folder **vdbench**
- The anchor value in the **fsd** field inside the **test1** file is the location of the partition equipped with the zfs filesystem. We used */zfs1/folder_name*, where **zfs1** is the name of pool created for zfs disk partition and **folder_name** is the folder inside which workload files are generated.
- *sudo zfs dedup=on zfs1* 
	> Go to vdbench folder
- The above command will set up the deduplication on for the zfs1 pool.
- *sudo ./vdbench -f test1 -o deduc_on >  deduc_on.txt*
- Here the **deduc_on** is the folder in which the output files will be generated and the terminal output will be stored in the **deduc_on.txt** file.
- *sudo rm -rf /zfs1/*
- The above command will delete the workload created in the current zfs pool.
- ***See report for detailed screenshots and results.*** 
### Workload for dedup=off:
- Copy the file **Assignment-4/dedup/test1** to the folder **vdbench**
- The anchor value in the **fsd** field inside the **test1** file is the location of the used partition for zfs filesystem. We used */zfs1/folder_name*, where **zfs1** is the name of pool created for zfs disk partition and **folder_name** is the folder inside which workload files are generated.
- *sudo zfs dedup=off zfs1*
	> Go to vdbench folder
- The above command will set up the deduplication off for the zfs1 pool.
- *sudo ./vdbench -f test1 -o deduc_off >  deduc_off.txt*
- Here the **deduc_off** is the folder in which the output files will be generated and the terminal output will be stored in the **deduc_off.txt file**.
- *df /zfs1/*
- The above command will list the disk usage for the used zfs filesystem 
- See report for detailed screenshots and results. 



## Compression

*Refer to the above sections for creation of file systems **ZFS** and **ext4***
### Workload for ZFS:
- Copy the file **Assignment-4/compression/test2_zfs** to the folder **vdbench**
- Create the zfs disk partition and create the pool named **zfs1**.
- The **anchor** value in the **fsd** field inside the **test2_zfs** file is the location of the used partition for zfs filesystem. We used */zfs1/folder_name*, where **zfs1** is the name of pool created for zfs disk partition and **folder_name** is the folder inside which workload files are generated.
- *sudo zfs set compression=on zfs1*
	> Go to vdbench folder
- The above command will set up the compression on for the zfs1 pool.
- *sudo ./vdbench -f test2_zfs -o compress_zfs >  compress_zfs.txt*
- Here the **compress_zfs** is the folder in which the output files will be generated and the terminal output will be stored in the **compress_zfs.txt file**.
- *sudo zpool destroy zfs1*
- The above command will remove the pool zfs1.
- ***See report for detailed screenshots and results***. 
### Workload for ext4:
- Copy the file **Assignment-4/dedup/test2_ext4** to the folder **vdbench**
- Create the **ext4** disk partition.
- The **anchor** value in the **fsd** field in the **test2_ext4** file is the location of the partition equipped with the **ext4** filesystem. We used */media/$USER/disk_name/folder_name*, where **disk_name** is the name of **ext4** disk partition and **folder_name** is the folder inside which workload files are generated.
	> Go to vdbench folder
- *sudo ./vdbench -f test2_ext4 -o compress_ext4 >  compress_ext4.txt*
- Here the **compress_ext4** is the folder in which the output files will be generated and the terminal output will be stored in the **compress_ext4.txt file**.
- ***See report for detailed screenshots and results***. 


