# CMPT 332 -- Fall 2017
# Assignment 2
# Derek Perrin 		dmp450 11050915
# Dominic McKeith 	dom258 11184543
#

Type 'make' into the console. Run the executable filesys-sim-threads.

THANKS FOR READING ME.

We would appreciate bonus marks for letting people use our monitor library.
