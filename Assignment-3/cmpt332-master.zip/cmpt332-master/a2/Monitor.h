/* CMPT 332 -- Fall 2017
* Assignment 2
* Derek Perrin      dmp450 11050915
* Dominic McKeith   dom258 11184543
*/
#define NO_CVS 7

void MonEnter(void);
void MonLeave(void);
void MonWait(int);
void MonSignal(int);
void MonInit(void);
