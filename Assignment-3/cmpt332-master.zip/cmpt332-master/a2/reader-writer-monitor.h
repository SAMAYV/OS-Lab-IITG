/* CMPT 332 -- Fall 2017
* Assignment 2
* Derek Perrin      dmp450 11050915
* Dominic McKeith   dom258 11184543
*/

#ifndef _READER_WRITER_MONITOR_H
#define _READER_WRITER_MONITOR_H

void StartRead(void);
void StopRead(void);
void StartWrite(void);
void StopWrite(void);

#endif /* _READER_WRITER_MONITOR_H */
